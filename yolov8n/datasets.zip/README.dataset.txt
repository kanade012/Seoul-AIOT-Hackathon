# Knife detection > 2024-03-02 4:12pm
https://universe.roboflow.com/train-yolov8-on-custom-dataset/knife-detection-azq4h

Provided by a Roboflow user
License: CC BY 4.0

